#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "MyStack.h"

//remove all even and return all the remove even as a new stack

int main() {
    Stack stackA;
    
    initStack(&stackA);
    
    Name name1 = createName("Joanna", "Alyssa", "Mondelo");
    Student stud1 = createStudent(1, name1, "Computer Science", 2);
    push(&stackA, stud1);

    Name name2 = createName("Jose", "Marie", "Chan");
    Student stud2 = createStudent(2, name2, "Mathematics", 3);
    push(&stackA, stud2);

    visualize(stackA);
    
    String searchProgram = "Mathematics";
    Name foundName = getStudentInProgram(stackA, searchProgram);
    
    // Check if a valid name was returned and display the result
    if (strcmp(foundName.fname, "") != 0) {  // Check if a name was found
        printf("Found student in program %s: %s %s %s\n", searchProgram, 
               foundName.fname, foundName.mname, foundName.lname);
    } else {
        printf("No student found in program %s.\n", searchProgram);
    }
    
    return 0;
}